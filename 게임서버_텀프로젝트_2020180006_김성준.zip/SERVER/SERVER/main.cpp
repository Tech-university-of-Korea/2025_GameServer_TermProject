#include "pch.h"

int32_t main()
{
	g_server.run();
}
