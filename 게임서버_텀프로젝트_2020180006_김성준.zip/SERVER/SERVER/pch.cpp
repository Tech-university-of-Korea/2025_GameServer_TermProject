#include "pch.h"

ServerFrame g_server;
Sectors g_sector;
SessionEbr g_session_ebr;