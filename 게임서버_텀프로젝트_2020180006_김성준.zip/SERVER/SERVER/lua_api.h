#pragma once

int32_t API_get_x(lua_State* L);
int32_t API_get_y(lua_State* L);