#pragma once

class MessageSystem {
public:

private:
};

