#include "pch.h"
#include "Console.h"

Console::Console() { }

Console::~Console() { 
    
}