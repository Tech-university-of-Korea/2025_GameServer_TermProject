#include <iostream>
#include <WS2tcpip.h>
#include <MSWSock.h>
#include <thread>
#include <vector>
#include <mutex>
#include <unordered_set>
#include <chrono>
#include <concurrent_priority_queue.h>
#include <concurrent_unordered_map.h>
#include <atomic>
#include "db_util.h"
#include "sector.h"

#include "include/lua.hpp"

#pragma comment(lib, "WS2_32.lib")
#pragma comment(lib, "MSWSock.lib")
#pragma comment(lib, "lua54.lib")
using namespace std;

enum EVENT_TYPE { EV_RANDOM_MOVE };

struct TIMER_EVENT {
	int obj_id;
	chrono::system_clock::time_point wakeup_time;
	EVENT_TYPE event_id;
	int target_id;
	constexpr bool operator < (const TIMER_EVENT& L) const
	{
		return (wakeup_time > L.wakeup_time);
	}
};
concurrency::concurrent_priority_queue<TIMER_EVENT> timer_queue;

enum COMP_TYPE { OP_ACCEPT, OP_RECV, OP_SEND, OP_NPC_MOVE, OP_AI_HELLO };
class OVER_EXP {
public:
	WSAOVERLAPPED _over;
	WSABUF _wsabuf;
	char _send_buf[BUF_SIZE];
	COMP_TYPE _comp_type;
	int _ai_target_obj;
	OVER_EXP()
	{
		_wsabuf.len = BUF_SIZE;
		_wsabuf.buf = _send_buf;
		_comp_type = OP_RECV;
		ZeroMemory(&_over, sizeof(_over));
	}
	OVER_EXP(char* packet)
	{
		_wsabuf.len = packet[0];
		_wsabuf.buf = _send_buf;
		ZeroMemory(&_over, sizeof(_over));
		_comp_type = OP_SEND;
		memcpy(_send_buf, packet, packet[0]);
	}
};

enum S_STATE { ST_FREE, ST_ALLOC, ST_INGAME };
class SESSION {
	OVER_EXP _recv_over;

public:
	mutex _s_lock;
	S_STATE _state;
	atomic_bool	_is_active;		// ������ �÷��̾ �ִ°�?
	int _id;
	SOCKET _socket;
	short	x, y;
	char	_name[NAME_SIZE];
	int		_prev_remain;
	unordered_set <int> _view_list;
	mutex	_vl;
	int		last_move_time;
	lua_State* _L;
	mutex	_ll;
public:
	SESSION()
	{
		_id = -1;
		_socket = 0;
		x = y = 0;
		_name[0] = 0;
		_state = ST_FREE;
		_prev_remain = 0;
	}

	~SESSION() {}

	void do_recv()
	{
		DWORD recv_flag = 0;
		memset(&_recv_over._over, 0, sizeof(_recv_over._over));
		_recv_over._wsabuf.len = BUF_SIZE - _prev_remain;
		_recv_over._wsabuf.buf = _recv_over._send_buf + _prev_remain;
		WSARecv(_socket, &_recv_over._wsabuf, 1, 0, &recv_flag,
			&_recv_over._over, 0);
	}

	void do_send(void* packet)
	{
		OVER_EXP* sdata = new OVER_EXP{ reinterpret_cast<char*>(packet) };
		WSASend(_socket, &sdata->_wsabuf, 1, 0, 0, &sdata->_over, 0);
	}
	void send_login_info_packet()
	{
		SC_LOGIN_INFO_PACKET p;
		p.id = _id;
		p.size = sizeof(SC_LOGIN_INFO_PACKET);
		p.type = SC_LOGIN_INFO;
		p.x = x;
		p.y = y;
		do_send(&p);
	}
	void send_login_fail_packet()
	{
		SC_LOGIN_FAIL_PACKET p;
		p.size = sizeof(SC_LOGIN_FAIL_PACKET);
		p.type = SC_LOGIN_FAIL;
		do_send(&p);
	}
	void send_move_packet(int c_id);
	void send_add_player_packet(int c_id);
	void send_chat_packet(int c_id, const char* mess);
	void send_remove_player_packet(int c_id)
	{
		_vl.lock();
		if (_view_list.count(c_id))
			_view_list.erase(c_id);
		else {
			_vl.unlock();
			return;
		}
		_vl.unlock();
		SC_REMOVE_OBJECT_PACKET p;
		p.id = c_id;
		p.size = sizeof(p);
		p.type = SC_REMOVE_OBJECT;
		do_send(&p);
	}
};

template <typename T>
using atomic_shared_ptr = std::atomic<std::shared_ptr<T>>;

HANDLE h_iocp;
std::atomic_int32_t g_new_client_id;

Concurrency::concurrent_unordered_map<int32_t, atomic_shared_ptr<SESSION>> clients;
SOCKET g_s_socket, g_c_socket;
OVER_EXP g_a_over;

bool is_pc(int object_id)
{
	return object_id < MAX_USER;
}

bool is_npc(int object_id)
{
	return !is_pc(object_id);
}

bool can_see(int from, int to)
{
	auto from_session = clients.at(from).load();
	auto to_session = clients.at(to).load();
	if (nullptr == from_session or nullptr == to_session) {
		return false;
	}

	if (abs(from_session->x - to_session->x) > VIEW_RANGE) return false;
	return abs(from_session->y - to_session->y) <= VIEW_RANGE;
}

bool login(int32_t session_id, const char* id)
{
	SQLRETURN retcode;
	SQLWCHAR user_id[NAME_LEN];
	SQLINTEGER user_x, user_y;
	SQLLEN cb_user_id = 0, cb_user_x = 0, cb_user_y = 0;

	auto session = clients.at(session_id).load();
	if (nullptr == session) {
		return false;
	}

	std::string exec{ "EXEC get_user_info " + std::string(id) };
	std::wstring wexec;
	wexec.assign(exec.begin(), exec.end());

	retcode = SQLExecDirect(h_stmt, (SQLWCHAR*)wexec.data(), SQL_NTS);
	if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {

		// Bind columns 1, 2, and 3  
		retcode = SQLBindCol(h_stmt, 1, SQL_C_WCHAR, &user_id, NAME_LEN, &cb_user_id);
		retcode = SQLBindCol(h_stmt, 2, SQL_C_LONG, &user_x, PHONE_LEN, &cb_user_x);
		retcode = SQLBindCol(h_stmt, 3, SQL_C_LONG, &user_y, PHONE_LEN, &cb_user_y);

		retcode = SQLFetch(h_stmt);
		if (retcode == SQL_ERROR || retcode == SQL_SUCCESS_WITH_INFO) {
			show_error();
			SQLCloseCursor(h_stmt);
			return false;
		}

		if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {
			//replace wprintf with printf
			//%S with %ls
			//warning C4477: 'wprintf' : format string '%S' requires an argument of type 'char *'
			//but variadic argument 2 has type 'SQLWCHAR *'
			//wprintf(L"%d: %S %S %S\n", i + 1, sCustID, szName, szPhone);  
			{
				lock_guard<mutex> ll{ session->_s_lock };
				session->x = user_x;
				session->y = user_y;
				session->_state = ST_INGAME;
			}
			printf("login confirm: id: [%ls],  x: %d y: %d\n", user_id, user_x, user_y);
			SQLCloseCursor(h_stmt);
			return true;
		}
		else {
			std::cout << "not exist user: " << id << "\n";

			session->send_login_fail_packet();
			SQLCloseCursor(h_stmt);
			return false;
		}
	}
	else {
		HandleDiagnosticRecord(h_stmt, SQL_HANDLE_STMT, retcode);
		SQLCloseCursor(h_stmt);
		return false;
	}
}

inline void update_user_pos(int32_t session_id)
{
	auto session = clients.at(session_id).load();
	if (nullptr == session) {
		return;
	}

	if (ST_INGAME != session->_state) {
		return;
	}

	std::string user_id{ session->_name };
	short x = session->x;
	short y = session->y;
	
	std::string exec{ "EXEC store_user_pos '" + user_id + "', " + std::to_string(x) + ", " + std::to_string(y)};
	std::wstring wexec;
	wexec.assign(exec.begin(), exec.end());

	SQLRETURN retcode;
	retcode = SQLExecDirect(h_stmt, (SQLWCHAR*)wexec.data(), SQL_NTS);
	if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {
		if (retcode == SQL_ERROR || retcode == SQL_SUCCESS_WITH_INFO) {
			show_error();
			SQLCloseCursor(h_stmt);
			return;
		}

		if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {
			printf("update confirm: id: [%s],  x: %d y: %d\n", session->_name, x, y);
			SQLCloseCursor(h_stmt);
			return;
		}
		else {
			std::cout << "update failure" << "\ns";
			SQLCloseCursor(h_stmt);
			return;
		}
	}
	else {
		HandleDiagnosticRecord(h_stmt, SQL_HANDLE_STMT, retcode);
		SQLCloseCursor(h_stmt);
		return;
	}
}

void disconnect(int c_id)
{
	auto session = clients.at(c_id).load();
	if (nullptr == session) {
		return;
	}

	erase_in_sector(session->_id, session->x, session->y);
	update_user_pos(session->_id);
	session->_vl.lock();
	unordered_set <int> vl = session->_view_list;
	session->_vl.unlock();

	for (auto& p_id : vl) {
		if (is_npc(p_id)) {
			continue;
		}

		auto pl = clients.at(p_id).load();
		{
			lock_guard<mutex> ll(pl->_s_lock);
			if (ST_INGAME != pl->_state) {
				continue;
			}
		}
		if (pl->_id == c_id) {
			continue;
		}

		pl->send_remove_player_packet(c_id);
	}
	closesocket(session->_socket);

	lock_guard<mutex> ll(session->_s_lock);
	session->_state = ST_FREE;
}

void SESSION::send_move_packet(int c_id)
{
	auto session = clients.at(c_id).load();
	if (nullptr == session) {
		return;
	}

	SC_MOVE_OBJECT_PACKET p;
	p.id = c_id;
	p.size = sizeof(SC_MOVE_OBJECT_PACKET);
	p.type = SC_MOVE_OBJECT;
	p.x = session->x;
	p.y = session->y;
	p.move_time = session->last_move_time;
	do_send(&p);
}

void SESSION::send_add_player_packet(int c_id)
{
	auto session = clients.at(c_id).load();
	if (nullptr == session) {
		return;
	}

	SC_ADD_OBJECT_PACKET add_packet;
	add_packet.id = c_id;
	strcpy_s(add_packet.name, session->_name);
	add_packet.size = sizeof(add_packet);
	add_packet.type = SC_ADD_OBJECT;
	add_packet.x = session->x;
	add_packet.y = session->y;
	_vl.lock();
	_view_list.insert(c_id);
	_vl.unlock();
	do_send(&add_packet);
}

void SESSION::send_chat_packet(int p_id, const char* mess)
{
	SC_CHAT_PACKET packet;
	packet.id = p_id;
	packet.size = sizeof(packet);
	packet.type = SC_CHAT;
	strcpy_s(packet.mess, mess);
	do_send(&packet);
}

void WakeUpNPC(int npc_id, int waker)
{
	auto npc = clients.at(npc_id).load();
	if (nullptr == npc) {
		return;
	}

	OVER_EXP* exover = new OVER_EXP;
	exover->_comp_type = OP_AI_HELLO;
	exover->_ai_target_obj = waker;
	PostQueuedCompletionStatus(h_iocp, 1, npc_id, &exover->_over);

	if (npc->_is_active) return;
	bool old_state = false;
	if (false == atomic_compare_exchange_strong(&npc->_is_active, &old_state, true)) {
		return;
	}

	TIMER_EVENT ev{ npc_id, chrono::system_clock::now(), EV_RANDOM_MOVE, 0 };
	timer_queue.push(ev);
}

void process_packet(int c_id, char* packet)
{
	auto session = clients.at(c_id).load();
	if (nullptr == session) {
		return;
	}

	switch (packet[1]) {
	case CS_LOGIN: {
		CS_LOGIN_PACKET* p = reinterpret_cast<CS_LOGIN_PACKET*>(packet);
		
		auto login_result = login(c_id, p->name);
		if (false == login_result) {
			disconnect(c_id);
			break;
		}

		strcpy_s(session->_name, p->name);

		session->send_login_info_packet();

		// �ֺ� 9�� ���� ��� �˻�
		auto [sector_x, sector_y] = add_in_sector(session->_id, session->x, session->y);
		for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
			auto [dx, dy] = DIRECTIONS[dir];
			if (false == valid_sector(sector_x + dx, sector_y + dy)) {
				continue;
			}

			std::lock_guard sector_guard{ sector_lock[sector_x + dx][sector_y + dy] };
			for (auto cl : sectors[sector_x + dx][sector_y + dy]) {
				auto client = clients.at(cl).load();
				if (nullptr == client) {
					continue;
				}

				{
					lock_guard<mutex> ll(client->_s_lock);
					if (ST_INGAME != client->_state) {
						continue;
					}
				}
				if (client->_id == c_id) {
					continue;
				}

				if (false == can_see(c_id, client->_id)) {
					continue;
				}

				if (is_pc(client->_id)) {
					client->send_add_player_packet(c_id);
				}
				else {
					WakeUpNPC(client->_id, c_id);
				}

				session->send_add_player_packet(client->_id);
			}
		}
		break;
	}
	case CS_MOVE: {
		CS_MOVE_PACKET* p = reinterpret_cast<CS_MOVE_PACKET*>(packet);
		session->last_move_time = p->move_time;
		short x = session->x;
		short y = session->y;
		switch (p->direction) {
		case 0: if (y > 0) y--; break;
		case 1: if (y < W_HEIGHT - 1) y++; break;
		case 2: if (x > 0) x--; break;
		case 3: if (x < W_WIDTH - 1) x++; break;
		}

		short old_x = session->x;
		short old_y = session->y;
		session->x = x;
		session->y = y;

		auto [sector_x, sector_y] = change_sector(session->_id, old_x, old_y, x, y);

		unordered_set<int> near_list;
		session->_vl.lock();
		unordered_set<int> old_vlist = session->_view_list;
		session->_vl.unlock();

		// �ֺ� 9�� ���Ϳ� ���� �˻�s
		for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
			auto [dx, dy] = DIRECTIONS[dir];
			if (false == valid_sector(sector_x + dx, sector_y + dy)) {
				continue;
			}

			std::lock_guard sector_guard{ sector_lock[sector_x + dx][sector_y + dy] };
			for (auto cl : sectors[sector_x + dx][sector_y + dy]) {
				auto client = clients.at(cl).load();
				if (nullptr == client) {
					continue;
				}

				if (client->_state != ST_INGAME) {
					continue;
				}

				if (client->_id == c_id) {
					continue;
				}

				if (can_see(c_id, client->_id)) {
					near_list.insert(client->_id);
				}
			}
		}

		session->send_move_packet(c_id);

		for (auto& pl : near_list) {
			auto client = clients.at(pl).load();
			if (nullptr == client) {
				continue;
			}

			if (is_pc(pl)) {
				client->_vl.lock();
				if (client->_view_list.count(c_id)) {
					client->_vl.unlock();
					client->send_move_packet(c_id);
				}
				else {
					client->_vl.unlock();
					client->send_add_player_packet(c_id);
				}
			}
			else {
				WakeUpNPC(pl, c_id);
			}

			if (0 == old_vlist.count(pl)) {
				session->send_add_player_packet(pl);
			}
		}

		for (auto& pl : old_vlist) {
			auto client = clients.at(pl).load();
			if (nullptr == client) {
				continue;
			}

			if (0 == near_list.count(pl)) {
				session->send_remove_player_packet(pl);
				if (is_pc(pl)) {
					client->send_remove_player_packet(c_id);
				}
			}
		}
	}
				break;
	}
}

void do_npc_random_move(int npc_id)
{
	auto npc = clients.at(npc_id).load();
	if (nullptr == npc) {
		return;
	}

	unordered_set<int> old_vl;
	// �����̱� �� ���Ϳ� �ִ� ������Ʈ�� ��� �߰�
	auto [prev_sector_x, prev_sector_y] = get_sector_idx(npc->x, npc->y);
	for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
		auto [dx, dy] = DIRECTIONS[dir];
		if (false == valid_sector(prev_sector_x + dx, prev_sector_y + dy)) {
			continue;
		}

		std::lock_guard sector_guard{ sector_lock[prev_sector_x + dx][prev_sector_y + dy] };
		for (auto cl : sectors[prev_sector_x + dx][prev_sector_y + dy]) {
			auto obj = clients.at(cl).load();
			if (nullptr == obj) {
				continue;
			}

			if (ST_INGAME != obj->_state) {
				continue;
			}

			if (true == is_npc(obj->_id)) {
				continue;
			}

			if (true == can_see(npc->_id, obj->_id)) {
				old_vl.insert(obj->_id);
			}
		}
	}

	int x = npc->x;
	int y = npc->y;
	switch (rand() % 4) {
	case 0: if (x < (W_WIDTH - 1)) x++; break;
	case 1: if (x > 0) x--; break;
	case 2: if (y < (W_HEIGHT - 1)) y++; break;
	case 3:if (y > 0) y--; break;
	}

	int old_x = npc->x;
	int old_y = npc->y;
	npc->x = x;
	npc->y = y;

	// ���� ����
	auto [curr_sector_x, curr_sector_y] = change_sector(npc->_id, old_x, old_y, x, y);

	// ������ �� ���Ϳ� �ִ� ������Ʈ�� �˻�
	unordered_set<int> new_vl;
	for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
		auto [dx, dy] = DIRECTIONS[dir];
		if (false == valid_sector(curr_sector_x + dx, curr_sector_y + dy)) {
			continue;
		}

		std::lock_guard sector_guard{ sector_lock[curr_sector_x + dx][curr_sector_y + dy] };
		for (auto cl : sectors[curr_sector_x + dx][curr_sector_y + dy]) {
			auto obj = clients.at(cl).load();
			if (nullptr == obj) {
				continue;
			}

			if (ST_INGAME != obj->_state) {
				continue;
			}

			if (true == is_npc(obj->_id)) {
				continue;
			}

			if (true == can_see(npc->_id, obj->_id)) {
				new_vl.insert(obj->_id);
			}
		}
	}

	for (auto pl : new_vl) {
		auto client = clients.at(pl).load();
		if (nullptr == client) {
			continue;
		}

		if (0 == old_vl.count(pl)) {
			// �÷��̾��� �þ߿� ����
			client->send_add_player_packet(npc->_id);
		}
		else {
			// �÷��̾ ��� ���� ����.
			client->send_move_packet(npc->_id);
		}
	}

	for (auto pl : old_vl) {
		auto client = clients.at(pl).load();
		if (nullptr == client) {
			continue;
		}

		if (0 == new_vl.count(pl)) {
			client->_vl.lock();
			if (0 != client->_view_list.count(npc->_id)) {
				client->_vl.unlock();
				client->send_remove_player_packet(npc->_id);
			}
			else {
				client->_vl.unlock();
			}
		}
	}
}

void do_npc_move(int npc_id, int32_t dx, int32_t dy)
{
	auto npc = clients.at(npc_id).load();
	if (nullptr == npc) {
		return;
	}

	unordered_set<int> old_vl;
	// �����̱� �� ���Ϳ� �ִ� ������Ʈ�� ��� �߰�
	auto [prev_sector_x, prev_sector_y] = get_sector_idx(npc->x, npc->y);
	for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
		auto [dx, dy] = DIRECTIONS[dir];
		if (false == valid_sector(prev_sector_x + dx, prev_sector_y + dy)) {
			continue;
		}

		std::lock_guard sector_guard{ sector_lock[prev_sector_x + dx][prev_sector_y + dy] };
		for (auto cl : sectors[prev_sector_x + dx][prev_sector_y + dy]) {
			auto obj = clients.at(cl).load();
			if (nullptr == obj) {
				continue;
			}

			if (ST_INGAME != obj->_state) {
				continue;
			}

			if (true == is_npc(obj->_id)) {
				continue;
			}

			if (true == can_see(npc->_id, obj->_id)) {
				old_vl.insert(obj->_id);
			}
		}
	}

	int x = npc->x + dx;
	int y = npc->y + dy;

	int old_x = npc->x;
	int old_y = npc->y;
	npc->x = x;
	npc->y = y;

	// ���� ����
	auto [curr_sector_x, curr_sector_y] = change_sector(npc->_id, old_x, old_y, x, y);

	// ������ �� ���Ϳ� �ִ� ������Ʈ�� �˻�
	unordered_set<int> new_vl;
	for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
		auto [dx, dy] = DIRECTIONS[dir];
		if (false == valid_sector(curr_sector_x + dx, curr_sector_y + dy)) {
			continue;
		}

		std::lock_guard sector_guard{ sector_lock[curr_sector_x + dx][curr_sector_y + dy] };
		for (auto cl : sectors[curr_sector_x + dx][curr_sector_y + dy]) {
			auto obj = clients.at(cl).load();
			if (nullptr == obj) {
				continue;
			}

			if (ST_INGAME != obj->_state) {
				continue;
			}

			if (true == is_npc(obj->_id)) {
				continue;
			}

			if (true == can_see(npc->_id, obj->_id)) {
				new_vl.insert(obj->_id);
			}
		}
	}

	for (auto pl : new_vl) {
		auto client = clients.at(pl).load();
		if (nullptr == client) {
			continue;
		}

		if (0 == old_vl.count(pl)) {
			// �÷��̾��� �þ߿� ����
			client->send_add_player_packet(npc->_id);
		}
		else {
			// �÷��̾ ��� ���� ����.
			client->send_move_packet(npc->_id);
		}
	}

	for (auto pl : old_vl) {
		auto client = clients.at(pl).load();
		if (nullptr == client) {
			continue;
		}

		if (0 == new_vl.count(pl)) {
			client->_vl.lock();
			if (0 != client->_view_list.count(npc->_id)) {
				client->_vl.unlock();
				client->send_remove_player_packet(npc->_id);
			}
			else {
				client->_vl.unlock();
			}
		}
	}
}

void worker_thread(HANDLE h_iocp)
{
	while (true) {
		DWORD num_bytes;
		ULONG_PTR key;
		WSAOVERLAPPED* over = nullptr;
		BOOL ret = GetQueuedCompletionStatus(h_iocp, &num_bytes, &key, &over, INFINITE);
		OVER_EXP* ex_over = reinterpret_cast<OVER_EXP*>(over);
		if (FALSE == ret) {
			if (ex_over->_comp_type == OP_ACCEPT) std::cout << "Accept Error";
			else {
				std::cout << "GQCS Error on client[" << key << "]\n";
				disconnect(static_cast<int>(key));
				if (ex_over->_comp_type == OP_SEND) delete ex_over;
				continue;
			}
		}

		if ((0 == num_bytes) && ((ex_over->_comp_type == OP_RECV) || (ex_over->_comp_type == OP_SEND))) {
			disconnect(static_cast<int>(key));
			if (ex_over->_comp_type == OP_SEND) delete ex_over;
			continue;
		}

		switch (ex_over->_comp_type) {
		case OP_ACCEPT: {
			int client_id = g_new_client_id++;
			if (client_id != MAX_USER) {
				auto new_session = std::make_shared<SESSION>();
				clients.insert(std::make_pair(client_id, new_session));

				auto session = clients.at(client_id).load();
				if (nullptr == session) {
					break;
				}

				{
					lock_guard<mutex> ll(session->_s_lock);
					session->_state = ST_ALLOC;
				}
				session->x = 0;
				session->y = 0;
				session->_id = client_id;
				session->_name[0] = 0;
				session->_prev_remain = 0;
				session->_socket = g_c_socket;
				CreateIoCompletionPort(reinterpret_cast<HANDLE>(g_c_socket),
					h_iocp, client_id, 0);
				session->do_recv();
				g_c_socket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
			}
			else {
				std::cout << "Max user exceeded.\n";
			}
			ZeroMemory(&g_a_over._over, sizeof(g_a_over._over));
			int addr_size = sizeof(SOCKADDR_IN);
			AcceptEx(g_s_socket, g_c_socket, g_a_over._send_buf, 0, addr_size + 16, addr_size + 16, 0, &g_a_over._over);
			break;
		}
		case OP_RECV: {
			int client_id = static_cast<int>(key);
			auto session = clients.at(client_id).load();
			if (nullptr == session) {
				break;
			}

			int remain_data = num_bytes + session->_prev_remain;
			char* p = ex_over->_send_buf;
			while (remain_data > 0) {
				int packet_size = p[0];
				if (packet_size <= remain_data) {
					process_packet(static_cast<int>(key), p);
					p = p + packet_size;
					remain_data = remain_data - packet_size;
				}
				else {
					break;
				}
			}
			session->_prev_remain = remain_data;
			if (remain_data > 0) {
				memcpy(ex_over->_send_buf, p, remain_data);
			}
			session->do_recv();
			break;
		}

		case OP_SEND:
			delete ex_over;
			break;

		case OP_NPC_MOVE: {
			int npc_id = static_cast<int>(key);
			auto npc = clients.at(npc_id).load();
			if (nullptr == npc) {
				break;
			}

			bool keep_alive = false;
			auto [sector_x, sector_y] = get_sector_idx(npc->x, npc->y);
			for (auto dir = 0; dir < DIRECTION_CNT; ++dir) {
				auto [dx, dy] = DIRECTIONS[dir];
				if (false == valid_sector(sector_x + dx, sector_y + dy)) {
					continue;
				}

				std::lock_guard sector_guard{ sector_lock[sector_x + dx][sector_y + dy] };
				for (auto cl : sectors[sector_x + dx][sector_y + dy]) {
					if (is_npc(cl)) {
						continue;
					}

					auto client = clients.at(cl).load();
					if (client->_state != ST_INGAME) continue;
					if (can_see(static_cast<int>(key), cl)) {
						keep_alive = true;
						break;
					}
				}
			}

			if (true == keep_alive) {
				npc->_ll.lock();
				auto L = npc->_L;
				lua_getglobal(L, "event_do_npc_random_move");
				if (LUA_OK != lua_pcall(L, 0, 0, 0)) {
					std::cout << lua_tostring(L, -1) << "\n";
					lua_pop(L, 1);
					npc->_ll.unlock();
					break;
				}

				lua_getglobal(L, "state_collision_with_player");
				lua_getglobal(L, "move_dx");
				lua_getglobal(L, "move_dy");
				auto state = (bool)lua_toboolean(L, -3);
				auto dx = (int32_t)lua_tointeger(L, -2);
				auto dy = (int32_t)lua_tointeger(L, -1);
				lua_pop(L, 3);
				npc->_ll.unlock();

				if (false == state) {
					do_npc_random_move(static_cast<int>(key));
				}
				else {
					do_npc_move(static_cast<int>(key), dx, dy);
				}

				TIMER_EVENT ev{ static_cast<int>(key), chrono::system_clock::now() + 1s, EV_RANDOM_MOVE, 0 };
				timer_queue.push(ev);
			}
			else {
				npc->_is_active = false;
			}
			delete ex_over;
			break;
		}
		case OP_AI_HELLO: {
			int npc_id = static_cast<int>(key);
			auto npc = clients.at(npc_id).load();
			if (nullptr == npc) {
				break;
			}

			npc->_ll.lock();
			auto L = npc->_L;
			lua_getglobal(L, "event_player_move");
			lua_pushnumber(L, ex_over->_ai_target_obj);
			if (LUA_OK != lua_pcall(L, 1, 0, 0)) {
				std::cout << lua_tostring(L, -1) << "\n";
				lua_pop(L, 1);
				npc->_ll.unlock();
				break;
			}
			//lua_pop(L, 1);
			npc->_ll.unlock();
			delete ex_over;
			break;
		}
		}
	}
}

int API_get_x(lua_State* L)
{
	int user_id =
		(int)lua_tointeger(L, -1);
	lua_pop(L, 2);

	auto client = clients.at(user_id).load();

	int x = client->x;
	lua_pushnumber(L, x);
	return 1;
}

int API_get_y(lua_State* L)
{
	int user_id =
		(int)lua_tointeger(L, -1);
	lua_pop(L, 2);

	auto client = clients.at(user_id).load();

	int y = client->y;
	lua_pushnumber(L, y);
	return 1;
}

int API_SendMessage(lua_State* L)
{
	int my_id = (int)lua_tointeger(L, -3);
	int user_id = (int)lua_tointeger(L, -2);
	char* mess = (char*)lua_tostring(L, -1);

	lua_pop(L, 4);

	auto client = clients.at(user_id).load();
	if (nullptr == client) {
		return 0;
	}

	client->send_chat_packet(my_id, mess);
	return 0;
}

void InitializeNPC()
{
	std::cout << "NPC intialize begin.\n";
	for (int i = MAX_USER; i < MAX_USER + MAX_NPC; ++i) {
		auto new_session = std::make_shared<SESSION>();
		clients.insert(std::make_pair(i, new_session));

		auto npc = clients.at(i).load();
		npc->x = rand() % W_WIDTH;
		npc->y = rand() % W_HEIGHT;
		npc->_id = i;
		sprintf_s(npc->_name, "NPC%d", i);
		npc->_state = ST_INGAME;

		auto _ = add_in_sector(npc->_id, npc->x, npc->y);

		auto L = npc->_L = luaL_newstate();
		luaL_openlibs(L);
		lua_register(L, "API_SendMessage", API_SendMessage);
		lua_register(L, "API_get_x", API_get_x);
		lua_register(L, "API_get_y", API_get_y);

		if (LUA_OK != luaL_loadfile(L, "npc.lua") or LUA_OK != lua_pcall(L, 0, 0, 0)) {
			std::cout << lua_tostring(L, -1) << "\n";
			lua_pop(L, 1);
			continue;
		}

		lua_getglobal(L, "set_uid");
		lua_pushnumber(L, i);
		lua_pcall(L, 1, 0, 0);
		//lua_pop(L, 1);// eliminate set_uid from stack after call
	}
	std::cout << "NPC initialize end.\n";
}

void do_timer()
{
	while (true) {
		TIMER_EVENT ev;
		auto current_time = chrono::system_clock::now();
		if (true == timer_queue.try_pop(ev)) {
			if (ev.wakeup_time > current_time) {
				timer_queue.push(ev);		// ����ȭ �ʿ�
				// timer_queue�� �ٽ� ���� �ʰ� ó���ؾ� �Ѵ�.
				this_thread::sleep_for(1ms);  // ����ð��� ���� �ȵǾ����Ƿ� ��� ���
				continue;
			}
			switch (ev.event_id) {
			case EV_RANDOM_MOVE:
				OVER_EXP* ov = new OVER_EXP;
				ov->_comp_type = OP_NPC_MOVE;
				PostQueuedCompletionStatus(h_iocp, 1, ev.obj_id, &ov->_over);
				break;
			}
			continue;		// ��� ���� �۾� ������
		}
		this_thread::sleep_for(1ms);   // timer_queue�� ��� ������ ��� ��ٷȴٰ� �ٽ� ����
	}
}

int main()
{
	WSADATA WSAData;
	WSAStartup(MAKEWORD(2, 2), &WSAData);
	g_s_socket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	SOCKADDR_IN server_addr;
	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT_NUM);
	server_addr.sin_addr.S_un.S_addr = INADDR_ANY;
	bind(g_s_socket, reinterpret_cast<sockaddr*>(&server_addr), sizeof(server_addr));
	listen(g_s_socket, SOMAXCONN);
	SOCKADDR_IN cl_addr;
	int addr_size = sizeof(cl_addr);

	init_db();
	InitializeNPC();

	h_iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, 0, 0, 0);
	CreateIoCompletionPort(reinterpret_cast<HANDLE>(g_s_socket), h_iocp, 9999, 0);
	g_c_socket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	g_a_over._comp_type = OP_ACCEPT;
	AcceptEx(g_s_socket, g_c_socket, g_a_over._send_buf, 0, addr_size + 16, addr_size + 16, 0, &g_a_over._over);

	vector <thread> worker_threads;
	int num_threads = std::thread::hardware_concurrency();
	for (int i = 0; i < num_threads; ++i)
		worker_threads.emplace_back(worker_thread, h_iocp);
	thread timer_thread{ do_timer };
	timer_thread.join();
	for (auto& th : worker_threads)
		th.join();

	cleanup_db();
	closesocket(g_s_socket);
	WSACleanup();
}
